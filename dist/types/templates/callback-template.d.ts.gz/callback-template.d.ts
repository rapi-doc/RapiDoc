import { RapiDocElement } from '@rapidoc-types';
import { OpenAPIV3 } from 'openapi-types';
export default function callbackTemplate(this: RapiDocElement, callbacks: OpenAPIV3.CallbackObject): import("lit-html").TemplateResult<1>;
//# sourceMappingURL=callback-template.d.ts.map