import { RapiDocElement } from '@rapidoc-types';
export declare function setApiServer(this: RapiDocElement, serverUrl: string): boolean;
export default function serverTemplate(this: RapiDocElement): "" | import("lit-html").TemplateResult<1>;
//# sourceMappingURL=server-template.d.ts.map