import { RapidocElement } from '@rapidoc-types';
export declare function setApiServer(this: RapidocElement, serverUrl: string): boolean;
export default function serverTemplate(this: RapidocElement): "" | import("lit-html").TemplateResult<1>;
//# sourceMappingURL=server-template.d.ts.map