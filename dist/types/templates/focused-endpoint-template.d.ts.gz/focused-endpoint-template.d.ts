import { TemplateResult } from 'lit';
import '../components/api-request';
import '../components/api-response';
import { RapidocElement } from '@rapidoc-types';
export default function focusedEndpointTemplate(this: RapidocElement): string | TemplateResult<1> | undefined;
//# sourceMappingURL=focused-endpoint-template.d.ts.map