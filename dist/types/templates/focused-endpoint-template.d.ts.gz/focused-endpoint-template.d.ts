import { TemplateResult } from 'lit';
import '../components/api-request';
import '../components/api-response';
import { RapiDocElement } from '@rapidoc-types';
export default function focusedEndpointTemplate(this: RapiDocElement): string | TemplateResult<1> | undefined;
//# sourceMappingURL=focused-endpoint-template.d.ts.map