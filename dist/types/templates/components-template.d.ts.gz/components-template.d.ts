import '../components/json-tree';
import '../components/schema-tree';
import '../components/schema-table';
import { RapidocElement } from '@rapidoc-types';
export default function componentsTemplate(this: RapidocElement): "" | import("lit-html").TemplateResult<1>;
//# sourceMappingURL=components-template.d.ts.map