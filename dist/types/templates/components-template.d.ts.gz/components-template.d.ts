import '../components/json-tree';
import '../components/schema-tree';
import '../components/schema-table';
import { RapiDocElement } from '@rapidoc-types';
export default function componentsTemplate(this: RapiDocElement): "" | import("lit-html").TemplateResult<1>;
//# sourceMappingURL=components-template.d.ts.map