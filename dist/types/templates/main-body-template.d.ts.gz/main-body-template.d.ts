import { RapiDocElement } from '@rapidoc-types';
export default function mainBodyTemplate(this: RapiDocElement, isMini?: boolean, showExpandCollapse?: boolean, showTags?: boolean, pathsExpanded?: boolean): "" | import("lit-html").TemplateResult<1>;
//# sourceMappingURL=main-body-template.d.ts.map