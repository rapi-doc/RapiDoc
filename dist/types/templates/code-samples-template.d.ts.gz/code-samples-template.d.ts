import { RapiDocXCodeSample } from '@rapidoc-types';
export default function codeSamplesTemplate(xCodeSamples: RapiDocXCodeSample[]): import("lit-html").TemplateResult<1>;
//# sourceMappingURL=code-samples-template.d.ts.map