import '../components/json-tree';
import '../components/schema-tree';
import { RapiDocJSONSchemaViewerElement } from '@rapidoc-types';
export default function jsonSchemaViewerTemplate(this: RapiDocJSONSchemaViewerElement, isMini?: boolean): "" | import("lit-html").TemplateResult<1>;
//# sourceMappingURL=json-schema-viewer-template.d.ts.map